import React from "react";

import Main from "../components/Main";

const Landing = ({ children }) => <Main>{children}</Main>;

export default Landing;
